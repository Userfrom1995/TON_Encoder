#pragma once

#define TD_HAVE_OPENSSL 1
#define TD_HAVE_ZLIB 1
#define TD_HAVE_CRC32C 1
#define TD_HAVE_LZ4 0
#define TD_HAVE_COROUTINES 0
#define TD_HAVE_ABSL 0
#define TD_FD_DEBUG 0
